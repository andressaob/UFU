package aula13032023;

public class Cliente {
    String nome, cpf, telefone, idade;
        
    void cadastrarCliente(String novoNome, String novoCPF, String novoTel, String novaIdade){
        nome = novoNome;
        cpf = novoCPF;
        telefone = novoTel;
        idade = novaIdade;
    }
    
    String mostrarDadosCliente(){
        return "\n\nNome: "+nome+"\nCPF: "+cpf+"\nTelefone: "+telefone+"\nIdade: "+idade+".";
    }
}
