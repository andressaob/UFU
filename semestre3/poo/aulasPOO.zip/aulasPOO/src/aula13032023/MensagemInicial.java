package aula13032023;

/*
Programa: exibicao da mensagem inicial (primeiro programa em java)
Responsavel: Andressa Oliveira Bernardes
Turma: Sistemas de Informacao           Criado em: 13/03/2023           Modificado em: --/--/----
Descricao: exibe uma mensagem simples na tela.
*/

public class MensagemInicial {
    public static void main(String a[]){
        System.out.println("Este eh o primeiro programa feito em Java!!!");
    }
}