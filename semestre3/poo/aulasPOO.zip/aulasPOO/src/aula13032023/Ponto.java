package aula13032023;


public class Ponto {
    float X, Y;
    
    void alteraX (float novoX){
        X = novoX;
    }
    void alteraY (float novoY) {
        Y = novoY;
    }
    
    float distanciaAB(float X, float Y, float XB, float YB){
        float D;
        /*calculo retirado do seguinte site: https://www.guj.com.br/t/calculo-distancia-processamento-de-imagens/116911 */
        D = (float) Math.sqrt(Math.sqrt(X - XB) + Math.sqrt(Y - YB));
        return D;
    }    
}
