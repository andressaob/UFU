package aula13032023;

import java.util.Scanner;

public class PrincipalCliente {
    public static void main(String a[]) {
        
        int op = -1;
        Scanner leitor = new Scanner(System.in);
        Cliente v[] = new Cliente[10];
        int ct = 0;
        
        do{
            System.out.println("\n1) Inserir cliente;");
            System.out.println("2) Mostrar clientes cadastrados;");
            System.out.print("OPCAO: ");
            op = leitor.nextInt();
            switch (op) {
                case 1:
                    String nome, cpf, telefone, idade;
                    System.out.print("Nome: ");
                    nome = leitor.next();
                    System.out.print("CPF: ");
                    cpf = leitor.next();
                    System.out.print("Telefone: ");
                    telefone = leitor.next();
                    System.out.print("Idade: ");
                    idade = leitor.next();
                    v[ct] = new Cliente();
                    v[ct].cadastrarCliente(nome, cpf, telefone, idade);
                    ct++;
                    break;
                case 2:
                    for (int i=0;i<ct;i++)
                        System.out.println(v[i].mostrarDadosCliente());
                    break;
            }
        }while (op != 5);
    }
}
