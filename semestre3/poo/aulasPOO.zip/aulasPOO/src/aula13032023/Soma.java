package aula13032023;

import java.util.Scanner;


public class Soma {
    public static void main(String a[]){
        int p1, p2, r;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Primeiro numero: ");
        p1 = scanner.nextInt();
        
        System.out.println("Segundo numero: ");
        p2 = scanner.nextInt();
     
        r = p1 + p2;
        
        System.out.println("A soma de "+p1+" + "+p2+"é igual a "+r+".");
    }
   
}