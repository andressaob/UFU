package aula13032023.tri;

public class Triangulo {
    int L1, L2, L3;
   
    void alteraL1(int novoL1){
        L1 = novoL1;
    }
    void alteraL2(int novoL2){
        L2 = novoL2;
    }
    void alteraL3(int novoL3){
        L3 = novoL3;
    }
   
    int retornaL1(){
        return L1;
    }
    int retornaL2(){
        return L2;
    }
    int retornaL3(){
        return L3;
    }
   
    int retornaPerimetro(){
        return L1+L2+L3;
    }
   
    String retornaTipo(){
        if((L1==L2)&&(L2==L3)) return "equilatero";
        else if ((L1!=L2)&&(L2!=L3)) return "escaleno";
                else return "isosceles";
    }
    
    String mostraDados() {
        return "Triangulo: Lado1 = "+retornaL1()+", Lado2 = "+retornaL2()+", Lado3 = "+retornaL3()+".";
    }
}
